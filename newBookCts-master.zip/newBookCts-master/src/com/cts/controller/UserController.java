package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.Entity.User;
import com.cts.Entity.Login;
import com.cts.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="index",method=RequestMethod.GET)
	private String indexPage() {
		return "index";
	}
	
	/*@RequestMapping(value="login",method=RequestMethod.GET)
	private String welcomePage() {
		return "login";
	}
	
	*/
	
	  @RequestMapping(value = "/registerpage", method = RequestMethod.GET)
	  public ModelAndView showRegister() {
	    ModelAndView mav = new ModelAndView("register");
	    mav.addObject("user", new User());
	    
	    return mav;
	  }
	  @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	  public ModelAndView addUser(@ModelAttribute("user") User user) throws Exception {
	  userService.registerUser(user);
	  return new ModelAndView("hello", "Name", user.getName());
	  }
	
	
	
	
	
	  @RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView showLogin() {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("login", new Login());
	    return mav;
	  }
	  @RequestMapping(value = "/loginuser", method = RequestMethod.POST)
	  public ModelAndView loginProcess(@ModelAttribute("login") Login login) throws Exception {
	    ModelAndView mav = null;
	    User user = userService.validateUser(login);
	    if (null != user) {
	    mav = new ModelAndView("hello");
	    mav.addObject("Name", user.getName());
	    } else {
	    mav = new ModelAndView("login");
	    mav.addObject("message", "Username or Password is wrong!!");
	    }
	    return mav;
	  }
		
		
		
	
}
