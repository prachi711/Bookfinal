package com.cts.Entity;

public class User {
	private String Name;
	  private String Username;
	  private String Password;
	  private String DOB;
	  private String Address;
	  
	 public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		this.Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		this.Password = password;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		this.DOB = dOB;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	
	  
	 
	}